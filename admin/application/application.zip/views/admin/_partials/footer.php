<footer class="sticky-footer bg-white">
    <div class="container my-auto">
        <div class="copyright text-center my-auto">
            <a href="http://travelingeropa.id/">
                <span>Copyright &copy; travelingeropapay.com 2019</span>
            </a>
        </div>
        <div class="copyright text-center my-auto">
            PHP:
            <?php echo phpversion(); ?>
            <?php echo (extension_loaded('openssl') ? 'SSL loaded' : 'SSL not loaded') . "\n"; ?>
        <div>
    </div>
</footer>